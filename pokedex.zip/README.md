# Real-Life Pokédex

Upload an image and click "Identify" to get a Pokédex-style description.

## Instructions:
1. Open `index.html` in a browser.
2. Replace `YOUR_OPENAI_API_KEY` in the code with your actual OpenAI API key.
3. Host on GitHub Pages for online access.
